; =============================================================================
;  Nutro+OS - MBR boot sector (stage 1)
;  ---------------------------------------------------------------------------
;  Loads stage 2 from LBA 1 (32 KB) to 0x8000:0000 and jumps to it.
;  The partition table at the end describes the FAT32 system partition.
; =============================================================================
BITS 16
ORG 0x7C00

%define STAGE2_LBA    1
%define STAGE2_SECTS  64
%define STAGE2_SEG    0x0800

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti
    cld
    mov [boot_drive], dl

    ; ---- check INT 13h extensions -------------------------------------
    mov ah, 0x41
    mov bx, 0x55AA
    int 0x13
    jc  .error
    cmp bx, 0xAA55
    jne .error

    ; ---- load stage 2 -------------------------------------------------
    mov ah, 0x42
    mov si, dap
    int 0x13
    jc  .error

    ; ---- verify stage 2 magic ("SN2!") --------------------------------
    cmp dword [STAGE2_SEG * 16 + 4], 0x21324E53
    jne .error

    mov dl, [boot_drive]
    jmp STAGE2_SEG:0x0000

.error:
    mov si, msg_err
.loop:
    lodsb
    test al, al
    jz  .hang
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    jmp .loop
.hang:
    cli
    hlt
    jmp .hang

msg_err   db 13, 10, "Nutro+OS: boot failure", 13, 10, 0
boot_drive db 0

align 4
dap:
    db 0x10, 0
dap_count dw STAGE2_SECTS
dap_off   dw 0x0000
dap_seg   dw STAGE2_SEG
dap_lba   dq STAGE2_LBA

; ---------------------------------------------------------------------------
;  Partition table (LBA 2048, 129024 sectors = 63 MB FAT32)
; ---------------------------------------------------------------------------
times 446 - ($ - $$) db 0
    db 0x80            ; bootable
    db 0x20, 0x21, 0x00  ; CHS start (head 32, sector 33, cyl 0)
    db 0x0C            ; type: FAT32 with LBA
    db 0x28, 0x20, 0x08  ; CHS end
    dd 2048            ; start LBA
    dd 129024          ; sector count
    times 3 * 16 db 0  ; entries 2..4 unused
    dw 0xAA55