; =============================================================================
;  Nutro+OS - stage 2 bootloader
;  ---------------------------------------------------------------------------
;   * reads the partition table (FAT32 partition LBA)
;   * E820 memory map
;   * A20 enable
;   * VBE mode selection (linear framebuffer, 32/24/16 bpp)
;   * unreal mode, loads KERNEL.BIN from the FAT32 volume to 0x00100000
;   * enters 32-bit protected mode and jumps to the kernel
; =============================================================================
BITS 16
ORG 0x8000

%define BOOTINFO      0x4000
%define VBE_INFO      0x5000
%define VBE_MODE_INFO 0x5400
%define VBE_MODELIST  0x5800
%define E820_COUNT    0x5FF0
%define E820_ADDR     0x6000
%define FATBUF        0x6800
%define BPBBUF        0x7000
%define FONT_ADDR     0x2000          ; 4 KiB BIOS 8x16 font copy (0x2000-0x2FFF)
%define DIRBUF_SEG    0x8000          ; 0x080000 - directory cluster scratch
%define BOUNCE_SEG    0x1000          ; 0x010000 - kernel bounce buffer
%define BOUNCE_MAX    (448 * 1024)
%define KERNEL_ADDR   0x00100000
; NOTE: 0x9F00 belongs to the BIOS (SeaBIOS keeps its internal stack there),
; so we use the classic boot stack just below the MBR.
%define STACK_TOP     0x7C00
%define S2_MAGIC      0x21324E53      ; "SN2!"

    jmp short s2_start
    times 2 nop
    dd S2_MAGIC

s2_start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, STACK_TOP
    sti
    cld
    mov [boot_drive], dl

; ---------------------------------------------------------------------------
;  Locate the FAT32 partition in the MBR partition table (at 0x7C00 + 446)
; ---------------------------------------------------------------------------
    mov si, 0x7C00 + 446
    mov cx, 4
.find_part:
    mov al, [si + 4]
    cmp al, 0x0B
    je  .found
    cmp al, 0x0C
    je  .found
    add si, 16
    loop .find_part
    mov si, msg_nopart
    jmp boot_error
.found:
    mov eax, [si + 8]
    test eax, eax
    jz   .next
    mov [part_lba], eax
    jmp .done
.next:
    add si, 16
    loop .find_part
    mov si, msg_nopart
    jmp boot_error
.done:

    call detect_memory
    call enable_a20
    call grab_bios_font
    call vbe_setup
    call load_kernel              ; real mode, BIOS disk reads, bounce buffer
    call build_bootinfo
    jmp  enter_pm                 ; one way trip: PM stub copies the kernel

; ===========================================================================
;  E820 memory map  ->  0x6000, count at 0x5FF0
; ===========================================================================
detect_memory:
    ; ---- 1st choice: ACPI E820 ------------------------------------------
    xor ebx, ebx
    mov di, E820_ADDR
    xor bp, bp
.loop:
    mov eax, 0xE820
    mov edx, 0x534D4D41
    mov ecx, 24
    mov dword [es:di + 20], 1        ; force ACPI 3.0 attributes
    int 0x15
    jc  .e820_done
    cmp eax, 0x534D4D41
    jne .e820_done
    cmp ecx, 20
    jb  .skip
    inc bp
    add di, 24
    cmp bp, 24
    jae .e820_done
.skip:
    test ebx, ebx
    jz  .e820_done
    jmp .loop
.e820_done:
    mov [E820_COUNT], bp
    test bp, bp
    jnz .done
    ; ---- 2nd choice: INT 15h AX=0xE801 ----------------------------------
    mov ax, 0xE801
    int 0x15
    jc  .try_88
    test ax, ax
    jnz .e801_ok
    mov ax, cx                       ; some BIOSes answer in CX/DX
    mov bx, dx
.e801_ok:
    movzx eax, ax                    ; KB between 1 MB and 16 MB
    shl eax, 10
    movzx ebx, bx                    ; 64 KB blocks above 16 MB
    shl ebx, 16
    add eax, ebx
    mov [mem_ext_bytes], eax
    jmp .synth
    ; ---- 3rd choice: INT 15h AH=0x88 ------------------------------------
.try_88:
    mov ah, 0x88
    int 0x15
    jc  .default_map
    movzx eax, ax
    shl eax, 10
    test eax, eax
    jz  .default_map
    mov [mem_ext_bytes], eax
    jmp .synth
.default_map:
    mov dword [mem_ext_bytes], 32 * 1024 * 1024
.synth:
    ; build a two entry map: conventional memory + the extended block
    mov dword [E820_ADDR + 0], 0
    mov dword [E820_ADDR + 4], 0
    mov dword [E820_ADDR + 8], 0x0009FC00
    mov dword [E820_ADDR + 12], 0
    mov dword [E820_ADDR + 16], 1
    mov dword [E820_ADDR + 20], 1
    mov dword [E820_ADDR + 24], 0x00100000
    mov dword [E820_ADDR + 28], 0
    mov eax, [mem_ext_bytes]
    mov dword [E820_ADDR + 32], eax
    mov dword [E820_ADDR + 36], 0
    mov dword [E820_ADDR + 40], 1
    mov dword [E820_ADDR + 44], 1
    mov word [E820_COUNT], 2
.done:
    ret

; ===========================================================================
;  Copy the BIOS 8x16 bitmap font (INT 10h AX=1130h BH=06h) to 0x2000
;  so the kernel can render crisp text into the framebuffer.
; ===========================================================================
grab_bios_font:
    mov ax, 0x1130
    mov bh, 6
    int 0x10
    cmp cx, 16                   ; bytes per character (DL is "rows-1")
    jne .none
    test bp, bp
    jz  .none
    push ds
    mov ax, es
    mov ds, ax
    mov si, bp
    xor ax, ax
    mov es, ax
    mov di, FONT_ADDR
    mov cx, 4096                 ; 256 characters * 16 bytes
    cld
    rep movsb
    pop ds
    mov dword [BOOTINFO + 68], FONT_ADDR
    mov dword [BOOTINFO + 72], 1
    ret
.none:
    mov dword [BOOTINFO + 68], 0
    mov dword [BOOTINFO + 72], 0
    ret

; ===========================================================================
;  A20 gate
; ===========================================================================
enable_a20:
    call .kbd_wait
    mov al, 0xD1
    out 0x64, al
    call .kbd_wait
    mov al, 0xDF
    out 0x60, al
    call .kbd_wait
    in  al, 0x92
    test al, 2
    jnz  .verify
    or  al, 2
    and al, 0xFE
    out 0x92, al
.verify:
    mov cx, 100
.vloop:
    push cx
    xor ax, ax
    mov ds, ax
    mov si, 0x0500
    mov word [si], 0xAAAA
    mov ax, 0xFFFF
    mov es, ax
    mov di, 0x0510
    mov word [es:di], 0x5555
    cmp word [si], 0xAAAA
    pop cx
    je  .ok
    loop .vloop
    mov si, msg_noa20
    jmp boot_error
.ok:
    xor ax, ax
    mov ds, ax
    mov es, ax
    ret
.kbd_wait:
    in  al, 0x64
    test al, 2
    jnz  .kbd_wait
    ret

; ===========================================================================
;  VBE: pick the best linear-framebuffer mode and set it
; ===========================================================================
vbe_setup:
    mov dword [VBE_INFO], 0x32454256     ; "VBE2"
    mov di, VBE_INFO
    xor ax, ax
    mov es, ax
    mov ax, 0x4F00
    int 0x10
    mov [tmp_ax], ax
    cmp ax, 0x004F
    je  .info_ok
    ; some VGA BIOSes answer the VBE2 request with a plain "VESA" block and
    ; a non-0x4F status - accept it as long as the block was filled in
    cmp dword [VBE_INFO], 0x41534556     ; "VESA"
    je  .info_ok
    jmp .fail_info
.info_ok:
    mov dword [best_score], 0
    mov word [best_mode], 0xFFFF

    ; ---- copy the mode list into RAM (INT 10h may clobber GS) ----------
    mov si, [VBE_INFO + 14]
    mov ax, [VBE_INFO + 16]
    mov gs, ax
    mov di, VBE_MODELIST
    mov cx, 128
.copy_modes:
    mov ax, [gs:si]
    mov [di], ax
    add si, 2
    add di, 2
    cmp ax, 0xFFFF
    je  .copy_done
    loop .copy_modes
    mov word [di], 0xFFFF                ; force a terminator
.copy_done:
    mov bp, 0
.scan:
    mov cx, [VBE_MODELIST + bp]
    cmp cx, 0xFFFF
    je  .scan_done
    add bp, 2
    call evaluate_mode
    jmp .scan
.scan_done:
    cmp word [best_mode], 0xFFFF
    jne .have_mode
    ; ---- no usable entry in the list: probe a built-in candidate table --
    mov bp, 0
.probe:
    mov cx, [probe_modes + bp]
    cmp cx, 0xFFFF
    je  .probe_done
    add bp, 2
    call evaluate_mode
    jmp .probe
.probe_done:
    cmp word [best_mode], 0xFFFF
    jne .have_mode
    mov si, msg_nomode
    jmp boot_error
.have_mode:
    mov bx, [best_mode]
    or  bx, 0x4000                       ; use linear framebuffer
    mov ax, 0x4F02
    int 0x10
    cmp ax, 0x004F
    jne .fail_set
    ; re-read the mode info: the BIOS may have updated it
    mov di, VBE_MODE_INFO
    xor ax, ax
    mov es, ax
    mov cx, [best_mode]
    mov ax, 0x4F01
    int 0x10
    cmp ax, 0x004F
    jne .fail_set
    ret
.fail_info:
    mov si, msg_noinfo
    call print_bios
    mov ax, [tmp_ax]
    call print_hex16
    mov si, msg_done
    jmp boot_error
.fail_set:
    mov si, msg_noset
    jmp boot_error

; ---------------------------------------------------------------------------
;  evaluate_mode: CX = candidate mode number
;     reads the mode info (4F01), scores it and remembers the best one.
; ---------------------------------------------------------------------------
evaluate_mode:
    push cx
    mov di, VBE_MODE_INFO
    xor ax, ax
    mov es, ax
    mov ax, 0x4F01
    int 0x10
    pop cx
    cmp ax, 0x004F
    jne .done
    mov ax, [VBE_MODE_INFO + 0]
    and ax, 0x0091                       ; supported + graphics + LFB
    cmp ax, 0x0091
    jne .done
    cmp byte [VBE_MODE_INFO + 27], 6     ; direct colour model
    jne .done
    movzx eax, byte [VBE_MODE_INFO + 25]
    cmp eax, 32
    je  .bpp32
    cmp eax, 24
    je  .bpp24
    cmp eax, 16
    je  .bpp16
    jmp .done
.bpp32:
    mov ebx, 30000000
    jmp .have_bpp
.bpp24:
    mov ebx, 20000000
    jmp .have_bpp
.bpp16:
    mov ebx, 10000000
.have_bpp:
    ; score = bpp_base + (1000000 - |width*height - 1024*768|)
    ; -> 32 bpp always beats 24 bpp, and 1024x768 is the sweet spot
    movzx eax, word [VBE_MODE_INFO + 18]
    movzx edx, word [VBE_MODE_INFO + 20]
    cmp eax, 640
    jb  .done
    cmp edx, 480
    jb  .done
    cmp eax, 1600
    ja  .done
    cmp edx, 1200
    ja  .done
    imul eax, edx
    sub eax, 786432
    test eax, 0x80000000
    jz  .abs_done
    neg eax
.abs_done:
    mov edx, 1000000
    sub edx, eax
    add edx, ebx
    cmp edx, [best_score]
    jbe .done
    mov [best_score], edx
    mov [best_mode], cx
.done:
    ret

; candidate modes for BIOSes whose mode list cannot be used
; (standard VESA numbers, 32 bpp first)
probe_modes:
    dw 0x0144, 0x0118, 0x0123, 0x0143, 0x0115, 0x0117, 0x0142, 0x0112
    dw 0x0114, 0x0111, 0x011B, 0x011A, 0xFFFF

; ===========================================================================
;  Nothing between here and the kernel touches the BIOS: all disk reads and
;  the mode setup happen in real mode, the kernel is moved to 1 MiB with a
;  flat 32-bit copy inside protected mode.
; ===========================================================================

; ===========================================================================
;  Load KERNEL.BIN from the FAT32 volume into the bounce buffer
; ===========================================================================
load_kernel:
    ; ---- read the BPB --------------------------------------------------
    mov eax, [part_lba]
    xor di, di
    mov es, di
    mov di, BPBBUF
    mov cx, 1
    call read_sectors

    mov al, [BPBBUF + 13]
    mov [fat_spc], al
    mov ax, [BPBBUF + 14]
    mov [reserved_sectors], ax
    mov al, [BPBBUF + 16]
    mov [num_fats], al
    mov eax, [BPBBUF + 36]
    mov [fat_size], eax
    mov eax, [BPBBUF + 44]
    mov [root_cluster], eax

    movzx eax, word [reserved_sectors]
    add eax, [part_lba]
    mov [fat_lba], eax

    movzx eax, byte [num_fats]
    imul eax, [fat_size]
    add eax, [fat_lba]
    mov [data_lba], eax

    ; ---- cluster geometry ----------------------------------------------
    movzx eax, byte [fat_spc]
    shl eax, 9
    mov [cluster_bytes], eax

    ; ---- read the root directory ---------------------------------------
    ; NOTE: set up ES:DI/CX *before* computing the LBA - AX is part of EAX
    mov ax, DIRBUF_SEG
    mov es, ax
    xor di, di
    movzx cx, byte [fat_spc]
    mov eax, [root_cluster]
    call cluster_to_lba
    call read_sectors

    ; ---- find KERNEL.BIN ------------------------------------------------
    xor bx, bx
.search:
    cmp bx, [cluster_bytes]
    jae .not_found
    mov al, [es:bx]
    test al, al
    jz  .not_found
    cmp al, 0xE5
    je  .next
    mov al, [es:bx + 11]
    cmp al, 0x0F
    je  .next                            ; long file name entry
    test al, 0x10
    jnz .next                            ; directory
    push si
    push di
    push cx
    mov si, bx
    mov di, kernel_name
    mov cx, 11
.cmp_loop:
    mov al, [es:si]
    cmp al, [di]
    jne .no_match
    inc si
    inc di
    loop .cmp_loop
    pop cx
    pop di
    pop si
    jmp .found
.no_match:
    pop cx
    pop di
    pop si
.next:
    add bx, 32
    jmp .search

.found:
    mov ax, [es:bx + 20]
    shl eax, 16
    mov ax, [es:bx + 26]
    mov [file_cluster], eax
    mov eax, [es:bx + 28]
    mov [file_size], eax

    ; ---- read the cluster chain into the bounce buffer -------------------
    mov ax, BOUNCE_SEG
    mov [cur_seg], ax
    mov dword [loaded], 0
.load_loop:
    mov eax, [file_cluster]
    cmp eax, 2
    jb  .load_end
    cmp eax, 0x0FFFFFF8
    jae .load_end
    mov eax, [loaded]
    add eax, [cluster_bytes]
    cmp eax, BOUNCE_MAX
    ja  .too_big

    mov ax, [cur_seg]                    ; set up ES:DI/CX before EAX is used
    mov es, ax
    xor di, di
    movzx cx, byte [fat_spc]
    mov eax, [file_cluster]
    call cluster_to_lba
    call read_sectors

    mov eax, [cluster_bytes]
    shr eax, 4
    add [cur_seg], ax
    mov eax, [cluster_bytes]
    add [loaded], eax

    mov eax, [loaded]
    cmp eax, [file_size]
    jae .load_end

    mov eax, [file_cluster]
    call fat_next_cluster
    mov [file_cluster], eax
    jmp .load_loop

.load_end:
    mov eax, [file_size]
    test eax, eax
    jz  .not_found
    mov [kernel_bytes], eax
    ret
.too_big:
    mov si, msg_big
    jmp boot_error
.not_found:
    mov si, msg_nokernel
    jmp boot_error

; ---------------------------------------------------------------------------
;  cluster_to_lba: eax = cluster -> eax = LBA   (clobbers edx)
; ---------------------------------------------------------------------------
cluster_to_lba:
    sub eax, 2
    movzx edx, byte [fat_spc]
    imul eax, edx
    add eax, [data_lba]
    ret

; ---------------------------------------------------------------------------
;  fat_next_cluster: eax = cluster -> eax = next cluster
; ---------------------------------------------------------------------------
fat_next_cluster:
    mov ebx, eax
    shl ebx, 2                            ; byte offset inside the FAT
    mov eax, ebx
    shr eax, 9
    add eax, [fat_lba]
    push ebx
    xor di, di
    mov es, di
    mov di, FATBUF
    mov cx, 1
    call read_sectors
    pop ebx
    and ebx, 511
    mov eax, [FATBUF + ebx]
    and eax, 0x0FFFFFFF
    ret

; ===========================================================================
;  Boot information block for the kernel (at 0x4000)
; ===========================================================================
build_bootinfo:
    mov dword [BOOTINFO + 0], 0x2B52544E       ; "NTR+" magic
    mov eax, [VBE_MODE_INFO + 40]
    mov [BOOTINFO + 4], eax                    ; framebuffer physical address
    movzx eax, word [VBE_MODE_INFO + 18]
    mov [BOOTINFO + 8], eax                    ; width
    movzx eax, word [VBE_MODE_INFO + 20]
    mov [BOOTINFO + 12], eax                   ; height
    movzx eax, word [VBE_MODE_INFO + 16]
    mov [BOOTINFO + 16], eax                   ; pitch
    movzx eax, byte [VBE_MODE_INFO + 25]
    mov [BOOTINFO + 20], eax                   ; bpp
    movzx eax, byte [VBE_MODE_INFO + 31]
    mov [BOOTINFO + 24], eax                   ; red mask size
    movzx eax, byte [VBE_MODE_INFO + 32]
    mov [BOOTINFO + 28], eax                   ; red position
    movzx eax, byte [VBE_MODE_INFO + 33]
    mov [BOOTINFO + 32], eax                   ; green mask size
    movzx eax, byte [VBE_MODE_INFO + 34]
    mov [BOOTINFO + 36], eax                   ; green position
    movzx eax, byte [VBE_MODE_INFO + 35]
    mov [BOOTINFO + 40], eax                   ; blue mask size
    movzx eax, byte [VBE_MODE_INFO + 36]
    mov [BOOTINFO + 44], eax                   ; blue position
    movzx eax, word [E820_COUNT]
    mov [BOOTINFO + 48], eax                   ; e820 entry count
    mov dword [BOOTINFO + 52], E820_ADDR
    mov eax, [part_lba]
    mov [BOOTINFO + 56], eax
    mov eax, [kernel_bytes]
    mov [BOOTINFO + 60], eax
    movzx eax, byte [boot_drive]
    mov [BOOTINFO + 64], eax
    ret

; ===========================================================================
;  Protected mode entry
; ===========================================================================
enter_pm:
    cli
    lgdt [gdt_desc]
    mov eax, cr0
    or  eax, 1
    mov cr0, eax
    jmp 0x08:pm_entry
BITS 32
pm_entry:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, STACK_TOP

    ; ---- move the kernel from the bounce buffer to 0x00100000 -----------
    mov esi, BOUNCE_SEG * 16
    mov edi, KERNEL_ADDR
    mov ecx, [kernel_bytes]
    add ecx, 3
    shr ecx, 2
    cld
    rep movsd

    mov eax, BOOTINFO
    jmp KERNEL_ADDR

BITS 16
; ===========================================================================
;  Disk helper: EAX = LBA, CX = count, ES:DI = destination
; ===========================================================================
read_sectors:
    push ax
    push cx
    push dx
    push si
    push di
    mov [dap_lba], eax
    mov [dap_count], cx
    mov [dap_off], di
    mov [dap_seg], es
    mov byte [rs_try], 5
.try:
    mov dl, [boot_drive]
    mov si, dap
    mov ah, 0x42
    int 0x13
    jnc .ok
    push ax
    xor ah, ah
    mov dl, [boot_drive]
    int 0x13
    pop ax
    dec byte [rs_try]
    jnz .try
    mov si, msg_diskerr
    jmp boot_error
.ok:
    pop di
    pop si
    pop dx
    pop cx
    pop ax
    ret

; ===========================================================================
;  Hex printing helpers (debug)
; ===========================================================================
print_hex16:
    push ax
    mov al, ah
    call print_hex8
    pop ax
    ; fall through (AL)
print_hex8:
    push ax
    shr al, 4
    call print_nibble
    pop ax
    and al, 0x0F
    ; fall through
print_nibble:
    add al, '0'
    cmp al, '9'
    jbe .out
    add al, 7
.out:
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    ret

; ===========================================================================
;  Error reporting (BIOS teletype - works in text and graphics modes)
; ===========================================================================
print_bios:
    lodsb
    test al, al
    jz  .done
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    jmp print_bios
.done:
    ret

boot_error:
    cli
    call print_bios
.hang:
    hlt
    jmp .hang

vbe_error:
    mov si, msg_novbe
    jmp boot_error

; ===========================================================================
;  Data
; ===========================================================================
msg_noinfo   db 13, 10, "Nutro+OS: VBE 4F00 failed, rc=", 0
msg_noset    db 13, 10, "Nutro+OS: VBE mode set (4F02) failed", 13, 10, 0
msg_nomode   db 13, 10, "Nutro+OS: no usable VBE mode found", 13, 10, 0
msg_done     db 13, 10, 0
msg_modeok   db " Nutro+OS: mode selected", 13, 10, 0
msg_nopart   db 13, 10, "Nutro+OS: no FAT32 partition found", 13, 10, 0
msg_noa20    db 13, 10, "Nutro+OS: A20 gate did not open", 13, 10, 0
msg_novbe    db 13, 10, "Nutro+OS: no suitable VBE mode", 13, 10, 0
msg_nokernel db 13, 10, "Nutro+OS: KERNEL.BIN not found", 13, 10, 0
msg_big      db 13, 10, "Nutro+OS: KERNEL.BIN too large", 13, 10, 0
msg_diskerr  db 13, 10, "Nutro+OS: disk read error", 13, 10, 0

kernel_name  db 'KERNEL  BIN'

boot_drive       db 0
part_lba         dd 0
fat_spc          db 0
reserved_sectors dw 0
num_fats         db 0
fat_size         dd 0
root_cluster     dd 0
fat_lba          dd 0
data_lba         dd 0
file_cluster     dd 0
file_size        dd 0
cluster_bytes    dd 0
loaded           dd 0
cur_seg          dw 0
kernel_bytes     dd 0
best_score       dd 0
best_mode        dw 0xFFFF
rs_try           db 0
tmp_ax           dw 0
mem_ext_bytes    dd 0

align 4
dap:
    db 0x10, 0
dap_count dw 1
dap_off   dw 0
dap_seg   dw 0
dap_lba   dq 0

align 8
gdt:
    dq 0
    dw 0xFFFF, 0x0000
    db 0x00, 0x9A, 0xCF, 0x00      ; 0x08: 32-bit code, 4 GB
    dw 0xFFFF, 0x0000
    db 0x00, 0x92, 0xCF, 0x00      ; 0x10: 32-bit data, 4 GB
gdt_end:
gdt_desc:
    dw gdt_end - gdt - 1
    dd gdt